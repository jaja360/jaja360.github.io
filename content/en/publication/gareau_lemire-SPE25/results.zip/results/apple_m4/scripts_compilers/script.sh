#!/bin/bash

# Under macOS, clang++ and g++ end up being the same compiler
CXX=clang++ cmake -B build . && cmake --build build
sudo ./scripts/generate_multiple_tables.py clang++
