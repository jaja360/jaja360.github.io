#pragma once

#include <vector>
#include <utility>

using veId    = unsigned long ;
using meters  = unsigned long ;
using nodeId  = unsigned long ;
using minutes = unsigned long ;
using speed   = unsigned long ;

using unitarySolution = std::tuple<std::vector<nodeId>, minutes, meters>;
using globalSolution = std::pair<std::vector<unitarySolution>, double>;
