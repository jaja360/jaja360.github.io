
#ifndef _OPTS_H
#define _OPTS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "flags.h"

void parse_opts( int argc, char *argv[] );
void show_opts( int argc, char *argv[] );

#endif
