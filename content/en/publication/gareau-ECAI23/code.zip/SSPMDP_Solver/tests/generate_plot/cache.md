# Cache results in var_states 1M

## TVI

- cache-references : 2940529045 (2.94G)
- cache-misses     : 1187956439 (1.19G)
- percent          : 40.47%

## eTVI

- cache-references : 2334704244 (2.33G)
- cache-misses     : 618004279 (0.618G)
- percent          : 26.52%

## eiTVI

- cache-references : 1648439190 (1.64G)
- cache-misses     : 526121154 (0.526G)
- percent          : 32.07%
