# SSP-MDP Solver

## About

- Author : **Jaël Champagne Gareau**
- University : **Université du Québec à Montréal**

## Dependencies

- [g++](https://gcc.gnu.org/) (>= 10)
- [glog](https://github.com/google/glog) for logging
- [gflags](https://gflags.github.io/gflags/) for args parsing
- [perl](https://www.perl.org/) for 'sap' domain generation

Example of command to install all dependencies on Ubuntu:
    - `apt install libgoogle-glog-dev libgflags-dev perl g++`

## Usage

- Run `make` to compile the code.
- Use `ulimit -s unlimited` to prevent a stack overflow on recursive function (e.g., tarjan).
- Type `./solver --helpshort` to show the available flags.

## Instruction to run the benchmark

- Create necessary folders:
    - `mkdir -p tests/domains/{layered/var_layers,layered/var_states,sap,wetfloor}`
- In `./tests`, do `./benchmark_all`
